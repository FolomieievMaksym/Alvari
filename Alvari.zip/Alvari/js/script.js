"use strict";

// function qs(element) {
//    let newEl = document.querySelector(element);
//    if (newEl) return newEl;
// }
// function qa(element) {
//    let newEl = document.querySelectorAll(element);
//    if (newEl) return newEl;
// }

import {} from "./lazy.js";
import {} from "./menu.js";
import {} from "./animate.js";
import {} from "./form.js";

// if (document.getElementById("video1")) {
// 				// <div class='first__bg'>
// 				// 	 <video muted playsinline src="@img/front.mp4" id="video1"></video>
// 				// 	 <video muted playsinline src="@img/back.mp4" id="video2"></video>
// 				// </div>
//    const video1 = document.getElementById("video1");
//    const video2 = document.getElementById("video2");
//    video1.addEventListener("ended", reverseVideo1);
//    video2.addEventListener("ended", reverseVideo2);
//    video1.style.zIndex = "1";
//    video2.style.zIndex = "0";
//    video1.play();
//    function reverseVideo1(e) {
//       video2.play();
//       video2.style.zIndex = "1";
//       video1.style.zIndex = "0";
//    }
//    function reverseVideo2(e) {
//       video1.play();
//       video1.style.zIndex = "1";
//       video2.style.zIndex = "0";
//    }
// }
